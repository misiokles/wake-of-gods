# Audyt mapObjects — WoG 3.59 alpha / VCMI 1.8.0

Porównanie dostarczonego portu Stack Experience 1.0.13 (katalog Mods/mapObjects identyczny bajtowo w 191 plikach ze sprawdzoną kopią ZIP) z repozytorium GrayFace WoG 3.59 alpha. To audyt statyczny mechanik i test ładowania VCMI 1.8.0, nie pełna rozgrywka ani deklaracja zgodności WoG 3.58f. Nie zmieniono produkcyjnych JSON/Lua.

19 głównych podmodów, 9 dodatków, 30 podstawowych typów obiektów (w tym patch fontanny core), 2702 podstawowe wpisy rewards oraz 80 onVisited. 73 pliki JSON w głównych podmodach i ich dodatkach odczytano parserem JSON5; 0 błędów parsera. Liczby nie oznaczają 2702 testów gry; duplikaty ważone Sphinx są liczone jako osobne wpisy. Pliki ERM odczytano bez uruchamiania EXE. Zestawiono aktywne polecenia ERM, konfiguracje i wybrane fragmenty silnika VCMI. Podano ścieżki względne: ERM = Mods/WoG/ERM, JSON = Mods/mapObjects/Mods/<podmod>/content/config (czasami mapObjects/).

## Testy i ograniczenia

Polecenie vcmiserver --dummy-run: kod 0, All game content loaded; 19/19 głównych podmodów i 2/9 dodatków w logu. Próba włączenia Mithril i trzech jego dodatków w osobnym profilu zakończyła się kodem 0, ale silnik wyłączył te moduły (Mithril wymaga osobnego moda vcmi, którego brak w aktywnym zestawie). Nie jest to test ich zgodności. Cztery dodatki frakcyjne również nieaktywne. Nie wykonano RMG, interakcji bohaterów, walk, testów AI, zapis/odczyt ani pełnych testów nagród. Statusy opisują porównanie statyczne.

## Wyniki dla podmodów

### Alms House — Korekta (P1)

**WoG:** Jednorazowy znacznik w13 na bohaterze; pomoc przy ruchu >0. 100 złota przy zerowym skarbcu, po 1 pozostałych zasobów; 1000 XP przy XP <1000; +1 ataku/obrony przy 0, mocy/wiedzy przy 1. Ruch zerowany, jeśli licznik pomocy >0 (XP sam zwiększa licznik tylko przy XP <200).

**VCMI:** selectAll, visitMode hero (na instancję); 1 złota, poziom <2, moc/wiedza <2, bez kosztu ruchu.

**Rekomendacja:** Popraw 1→100 złota; w miarę możliwości odwzoruj zerowanie ruchu i globalną jednorazowość dla bohatera. Nie zamieniaj warunku XP na <200: to warunek licznika, nie nagrody.

*Źródła:* `script018.erm:38–50, 60–108, 117–122`; `almsHouse.json`.

### Altar of Transformation — Adaptacja (P2)

**WoG:** Raz na tydzień na ołtarz; odmowa; inwestycja 0–100 SP z dostępnymi pośrednimi wartościami, losowanie docelowej frakcji także na poziomie stosu; AI bez many. Wyjątki Ghost, Emissaries, smoki neutralne, szczególne warianty jednostek.

**VCMI:** 20 gałęzi (10 kierunków za 100 SP oraz 10 losowych bez SP), tygodniowy reset, selectPlayer, canRefuse false; stałe mapowania 140–142 typów na kierunek.

**Rekomendacja:** Zachowaj wybraną kompaktową wersję 10 kierunków + losowanie. Sprawdź odmowę, stosy mieszane, liczbę jednostek, doświadczenie i banowane jednostki. Pośrednie nakłady many jako świadomie pominięte. Zweryfikuj reguły dla Faerie Dragon, nie zakładaj zgodności 1:1.

*Źródła:* `script014.erm:78, 131–175, 193–285 i dalsze funkcje transformacji`; `altarOfTransformation.json`.

### Arcane Tower — Adaptacja (P2)

**WoG:** Gracz wybiera atrybut zysku i kosztu, może powtarzać do 30 razy w jednej sesji; bez kosztu ruchu; GetBasicPrim sprawdza statystyki bez artefaktów. Wizyta aktywna dla człowieka.

**VCMI:** 12 kierunków wymiany, jeden losowy kwalifikujący się, 300 ruchu, nieograniczone wizyty i odmowa.

**Rekomendacja:** Koszt jest celową zmianą balansu, nie WoG. Rozważ selectPlayer z 12 opcjami tylko jeśli interfejs pozostaje wygodny. Testuj minimum atrybutu przy założonych artefaktach.

*Źródła:* `script004.erm:43–47, 55–90, 98–138`; `arcaneTower.json`.

### Artificer — Korekta (P1)

**WoG:** Dwie usługi dziennie, druga podwójnie płatna; 100 ruchu; ceny zależne od dnia, Estates + Diplomacy (niższy poziom), artefaktów dyplomacji, ograniczeń artefaktów.

**VCMI:** 80 podstawowych przepisów i 80 onVisited; dodatki dopisują receptury. Natywna ścieżka onVisited bierze pierwszy dostępny i przyznaje go bez dialogu odmowy; brak osobnego limitu drugiej usługi.

**Rekomendacja:** Najpierw wyeliminuj automatyczne płatne transakcje przy ponownej wizycie. Bezpieczny wariant JSON: jedna świadomie akceptowana usługa dziennie; drugi zakup wymaga odrębnego rozwiązania. Ceny i wybór przepisów zweryfikować później.

*Źródła:* `script026.erm:26–56, 509–543, 709–711, 1361–1363, 1605–1607; VCMI Interface.cpp:343–350, 480–492`; `artificer.json + dodatki`.

### Battle Academy — Adaptacja (P2)

**WoG:** Menu wyboru; koszt 500×bazowy atak/obrona; 3000 za skill; możliwość płatnego dodatkowego ukrytego skilla; losowy skill i artefakt na turę; dzienny znacznik w38 na bohaterze.

**VCMI:** 217 gałęzi; jedna losowa oferta, 198 statystyk, 3 ścieżki skilla i 16 artefaktów; reset dzienny per budynek; commanderArtifacts opcjonalnie.

**Rekomendacja:** Sprawdzić bazowe statystyki, zakres globalnego limitu i koszt dodatkowych slotów. Nie deklarować pełnej zgodności z WoG.

*Źródła:* `script016.erm:22–26, 63–109, 169–207, 230–315`; `battleAcademy.json`.

### Death Chamber — Adaptacja (P1)

**WoG:** Tygodniowy wzrost od dnia 15, od czwartego tygodnia przemiana króla w Dracolicha, Armageddon po drugiej rundzie, Inferno i Anti-Magic, dodatkowi strażnicy po śmierci króla. Respawn po 28 dniach. Ghosts 10–18 przed tygodniem 4, potem +2; złoto i Mithril wg liczników.

**VCMI:** 4 stałe warianty losowane w obiekcie; 9000–18000 złota, 20–50 Ghosts; opcjonalnie 4–10 Mithril; brak resetu. Lua odtwarza pole i fazy, modyfikuje czary; jeden nagrobek przesunięty z 30 na 29.

**Rekomendacja:** Priorytet: respawn i skalowanie kalendarzem (jeśli API pozwala), Dracolich, warunkowe przywołania i oryginalna ekonomia. Zachować dostęp dwupolowych jednostek. Testować zwycięstwo, przegraną, odmowę, ponowną wizytę i AI. Nie zmieniać skryptu bez osobnych testów.

*Źródła:* `script070.erm:82–117, 292–409, 440–509, 528–586`; `deathChamberObject.json; creatures.json; deathChamberKing.lua; deathChamberCurse.lua`.

### Fishing Well — Adaptacja (P2)

**WoG:** Rozszerza zwykłe Magic Wells. Gracz może odmówić; koszt 5000 ruchu z dolnym limitem 0, AI zwolnione; losowania złożone, tunele między studniami, pułapki i potwory.

**VCMI:** Osobny obiekt, globalnie 1 połów na studnię/tydzień, brak odmowy, 43 gałęzie, 30% pustych połowów, zawsze 100% many i 0% ruchu; brak tuneli.

**Rekomendacja:** Zachować uzgodnioną wersję tygodniową, oznaczyć jako reinterpretację. Rozważyć odmowę, kontrolę realnego kosztu dla ruchu >5000 oraz test strażników/resetu. 30% nie jest dokładnym rozkładem ERM.

*Źródła:* `script007.erm:86–138, 142–281, 296–449, 451–514`; `fishingWell.json`.

### Forgotten Shrine — Bliski port (P2)

**WoG:** >200 ruchu, modlitwa do odmowy, zerowanie ruchu, jeden z 20 czarów Expert do następnej bitwy; osobne sprawdzanie jednostek, artefaktów i terenu, wygaśnięcie po bitwie.

**VCMI:** 20 rewardów OPENING_BATTLE_SPELL z 50 rundami, ONE_BATTLE, addInfo 3, min 201 i 0 ruchu; osobny obiekt.

**Rekomendacja:** Zostawić konfigurację do testów wszystkich czarów, zwłaszcza Frenzy/Anti-Magic/Magic Mirror, na Cursed Ground, z Orb i zakazami magii; dopiero po testach ocenić potrzebę Lua.

*Źródła:* `script060.erm:65–90, 126–149 i FU13–16`; `forgottenShrine.json`.

### Junk Merchant — Adaptacja (P2)

**WoG:** 32 artefakty i zwoje, tylko plecak, po jednej kopii danego artefaktu na wizytę; wiele transakcji w sesji; AI odrzuca nagrody w stworzeniach.

**VCMI:** 32 wymiany i 70 sprzedaży zwojów, 500 złota za zwój, losowa kwalifikująca się oferta, bez limitu wizyt; opcjonalnie 2 Supreme Archangels za Angel Wings zamiast 5 Archangels.

**Rekomendacja:** Zweryfikować zużywanie założonych artefaktów i zgodność 32 cen/rewardów. Sprawdzić zachowanie AI i zakazane czary; lista zwojów nie obejmuje automatycznie modów.

*Źródła:* `script008.erm:8–18, 202–245 i tablice transakcji`; `junkMerchant.json + junkMerchantLevel8.json`.

### Magic Mushrooms — Bliski port (P3)

**WoG:** Rzeczywiste tymczasowe nabycie Expert w jednej szkole, globalny znacznik per szkoła/bohater i odtworzenie poprzedniego poziomu w poniedziałek; brak korzyści dla Expert.

**VCMI:** 4 obiekty, MAGIC_SCHOOL_SKILL val=3 ONE_WEEK; tymczasowy bonus, nie nabyta secondary skill.

**Rekomendacja:** Nie zmieniać bez testu końca tygodnia i dwóch grzybów tej samej szkoły. Sprawdzić bonus specjalizacji, wymagania innych mechanik oraz już posiadaną magię Expert.

*Źródła:* `script010.erm:85–98, 111–170`; `mushrooms.json`.

### Mirror of the Home-Way — Bliski port (P2)

**WoG:** Opłata 1000 złota, lista maks. 11 własnych miast, AI ma 25% szansy zgody, bezpośrednie przeniesienie HE:P po zapłacie.

**VCMI:** 1000 złota, unlimited, odmowa, Expert Town Portal przez spellCast.

**Rekomendacja:** Cena zgodna (stary dokument jest błędny). Sprawdzić brak miast, zajęte miasto, ruch i anulowanie wyboru miasta, w szczególności kolejność pobrania złota przy nieudanym teleportowaniu.

*Źródła:* `script052.erm:64–98, 102–107, 193–215`; `mirrorOfTheHomeWay.json`.

### New Chest I — Adaptacja (P2)

**WoG:** Typ 101/1, wariant z pozycji na mapie; dynamiczna kalkulacja wartości upgrade; 1000/1500/2000 typowo; pułapki to czary 73,71,45,54 (Disease, Poison, Weakness, Slow) Basic na 255 rund na jednostki. Expert Luck lub Intelligence chroni.

**VCMI:** 3 osobne typy; 10+2+6 gałęzi; 5 ustalonych upgrade; wartości 1000–3000; pułapki -1 morale/luck/attack/defence; odporność Expert Luck/Intelligence.

**Rekomendacja:** Nie podmieniać ustalonego balansu bez zgody. Rozważyć prawdziwe efekty czarów pułapek i test dynamicznej wartości stosów. Zbadać UI i usuwanie skrzyń.

*Źródła:* `script029.erm:42–63, 68–127, 137–162, 175–200, 224–250`; `newChestI.json`.

### New Chest II — Adaptacja (P1)

**WoG:** 20% akt kopalni, 40% tomy, 40% scroll+300–900 złota; dwa różne znane skille do wyboru; jeśli mniej niż dwa lub trwa nauka, przejście do scrolla. Tom zapisuje 7 dni, po ukończeniu ustawia Expert; kopalnia przejmuje się zdalnie.

**VCMI:** 39 gałęzi; rozkład 40/40/20 w konfiguracji; natychmiastowy +1 rank, wybór wszystkich kwalifikujących, 500 gold fallback; deed 2000 gold; poziom scrolla z progu heroLevel.

**Rekomendacja:** Dokumentację poprawić: ERM 3.59 nie daje +1 natychmiast. Zachować świadomy zamiennik aktu kopalni bez API mapowego; odtworzenie tygodniowej nauki wymaga trwałego stanu i zdarzenia dnia.

*Źródła:* `script031.erm:96–117, 122–215, 224–289, 331–369, 399 i dalsze`; `newChestII.json`.

### Palace of Dreams — Korekta (P1)

**WoG:** 400 ruchu na wejście, 100 gold za spin, dwa automaty, do 100 obrotów w sesji; nagrody zależne od wylosowanych symboli i czasu gry.

**VCMI:** 5 nagród, losowy rezultat, jeden globalny raz/dzień, próg 1000 gold, brak ruchu. Gałęzie minor i major dodają +2000/+5000 gold bez odjęcia stawki.

**Rekomendacja:** Uzgodnić model ekonomiczny: nie traktować jackpotów jako kosztu 1000. Dodać zgodny koszt ruchu lub jasno opisać zmianę. Dokładna emulacja automatu to osobny projekt.

*Źródła:* `script011.erm:98–115, 126–208, 217–277`; `palaceOfDreams.json`.

### Potion Fountains — Adaptacja (P1)

**WoG:** 3 dawki w zmiennej bohatera, odwiedziny dopełniają do 3; decyzja o wypiciu w walce, zużycie tylko po akceptacji; bonusy czasowe, wyjątki AI i interakcje mieszanek.

**VCMI:** 3 artefakty MISC, po 3 ładunki BATTLE; bonusy podczas noszenia, Hydromel wraz z losowym Luck; Venus i Berserker reset tygodniowy; brak oryginalnej decyzji o wypiciu.

**Rekomendacja:** Sprawdzić czy +10/+2 działa także na mapie (PRIMARY_SKILL bez limitu walki), zużycie ładunków w każdej walce, wiele fiolek i kombinacje. Jeśli świadomie pozostawiamy artefakty, opisać zmianę; nie obiecywać wiernej repliki.

*Źródła:* `script017.erm:65–115, 118–252 i dalsze`; `fountains.json; hydromelPotion.json; berserkerPotion.json; venusBlessing.json`.

### School of Wizardry — Adaptacja (P2)

**WoG:** Bazowy koszt (moc/wiedza−1)×500; jedna usługa na bohatera/dzień; menu; 3000 gold skill i dodatkowe ukryte skille za dopłatą; cena zaklęcia wg ID; Expert Wisdom dla scroll copy; spellbook 250.

**VCMI:** 345 gałęzi, 200 szkolenia atrybutów, 15 secondary, 129 spell rewards (w tym 69 copy), spellbook 250; losowa oferta, dzienny reset per obiekt, statyczne listy.

**Rekomendacja:** Zachować próg Expert Wisdom (jest oryginalny), sprawdzić ceny czarów i bazowe atrybuty, losowanie oferty i limit bohatera między szkołami.

*Źródła:* `script028.erm:24–32, 145–185, 204–251, 268–344, 346–499`; `schoolOfWizardry.json`.

### Spell Book — Bliski port (P2)

**WoG:** Zwykły artefakt spellbook, 3 L1 +3 L2, progi 4/7/9 dla +2 L3/+2 L4/+1 L5; rzut clamp(R0–9 + Luck +2×Wisdom−6); wykluczenia czarów ruchu przygód i powtórzeń losowań w ramach poziomu.

**VCMI:** Oddzielny usuwany obiekt, 94 gałęzie, ten sam schemat liczby zaklęć; JSON używa losowań wg poziomu.

**Rekomendacja:** Zweryfikować brak czarów ruchowych (nie występuje jawne wykluczenie w rewardach), brak duplikatów, naukę bez Wisdom, istniejący spellbook. Obiekt oddzielny to świadomy kompromis.

*Źródła:* `script027.erm:10, 18–97`; `spellBook.json`.

### Sphinxes — Reinterpretacja (P3)

**WoG:** Wariant 3.59: człowiek może odmówić; 3 pytania i 3 próby odgadnięcia potwora. Sukces daje stworzenia, porażka walkę z trzykrotnie większą liczbą; nagrody rosną tygodniowo. Koszt min(2000, ruch), wymaga >0; triggery 63/10–13.

**VCMI:** 6 obiektów po 280 rewardów; 50/50 błogosławieństwo/klątwa, 12+12 typów na 1–7 dni, koszt 1280, raz dziennie per Sphinx per hero, bez odmowy.

**Rekomendacja:** Pozostawić świadomie wybraną reinterpretację. Nie opisywać jej jako wiernego portu Script98. Testować rzeczywiste wygaśnięcie, dochód, stacking i moment pobierania ruchu.

*Źródła:* `Script098.erm:11–18, 29–82; Usage359.txt:1390`; `sphinx.json`.

### War Machines on Map — Rozszerzenie (P3)

**WoG:** Nie potwierdzono bezpośredniej zgodności z jedną mechaniką 3.59. Należy oddzielić od Enhanced War Machines I–III.

**VCMI:** 5 zmian klas/grafik artefaktów core: Grail RELIC, Catapult SPECIAL, Ballista MAJOR, Ammo Cart i First Aid Tent MINOR; zwykły spellbook usunięty z tej paczki.

**Rekomendacja:** Sprawdzić RMG, Grail jako losowy artefakt, Catapult SPECIAL i pickup. Klasa SPECIAL może ograniczać generowanie; samo wczytanie nie dowodzi pojawiania się na mapie.

*Źródła:* `Brak ustalonego odpowiednika pojedynczego ERM; script027.erm dotyczy tylko spellbook`; `warMachinesArts.json`.

## Dodatki i integracja

- **Altar – Cove / Factory / Bulwark / Tides of War:** 4 osobne patchujące podmody; mapowania są przywiązane do indeksów modify@. Zmiana kolejności 20 gałęzi wymaga synchronizacji. Nie aktywne: brak zależności zewnętrznych.
- **Artificer – Mithril Recipes / Dragon Eye Ring:** 39 dodatkowych przepisów i jeden opcjonalny przepis; przywracają część ekonomii Mithril, ale dziedziczą problem onVisited. Nie aktywne.
- **Death Chamber – Mithril:** 4/6/8/10 Mithril, statyczna tabela zamiast licznika ERM. Nie aktywny.
- **Battle Academy – Commander Artifacts:** 5 artefaktów za 15000 gold; aktywny w teście ładowania.
- **Junk Merchant – Level 8 Units:** Zamiana nagrody Angel Wings na 2 Supreme Archangels; aktywny w teście ładowania.
- **_temp:** Nie jest podmodem: plik mod.jsona zamiast mod.json; kopie archiwalne poza zakresem wykonania. Nie usuwać automatycznie.

## Plan napraw

Kolejność prac: (1) Artificer – bezpieczeństwo transakcji, (2) Alms House – 100 gold i ograniczenia, (3) New Chest II – decyzja o tygodniowej nauce, (4) Palace – ekonomia, (5) Death Chamber – respawn, skalowanie i walki, (6) Potion Fountains – ładunki i zakres bonusów, (7) regresja wszystkich obiektów P2/P3. Wierność 3.59 nie wymaga rezygnacji z uzgodnionych zmian Sphinx, Fishing Well i Altar. Każdą poprawkę testować osobno, bez zmian C++.

## Korekty starszej dokumentacji

W przekazanym `description/english.md` należy zastąpić nieaktualne informacje o Mirror (płatność 1000 jest aktywna), Palace (400 ruchu), Alms House (próg nagrody XP <1000), New Chest II (7 dni do Expert) i Sphinx (Script098 zgadywanie stworzenia w 3.59). Nie nadpisano istniejącego przewodnika; ten dokument stanowi uzupełnienie audytu.


## Aktualizacja — Artificer 1.0.1

Wprowadzono bezpieczną korektę JSON w głównym podmodzie oraz dodatkach Mithril Recipes i Dragon Eye Ring. Usunięto wszystkie 120 płatnych receptur `onVisited`. W VCMI `Rewardable::Interface::doHeroVisit()` wywołuje w przypadku ponownej wizyty `grantRewardWithMessage(..., false)` dla pierwszego pasującego wpisu, bez `canRefuse` i bez losowania; pozostawiono tylko neutralny `onVisitedMessage`. Wszystkie 120 pierwotnych receptur pierwszej wizyty zachowuje identyczne artefakty, opłaty, koszt ruchu i treść oferty; do limiterów dodano `movePoints: 100`.

**WoG 3.59:** `script026.erm:174–187, 509–535, 710–727, 1361–1379, 1605–1623` — licznik zmęczenia jest zapisany na obiekcie przez `PO`, zatem dwie usługi dziennie są współdzielone między odwiedzającymi bohaterami. Druga usługa ma podwójną stawkę; ceny mogą zależeć od czasu, Estates, Diplomacy i artefaktów dyplomatycznych. Kod ruchu odejmuje 100, a poniżej 100 zeruje pozostały ruch.

**VCMI 1.8:** jedna zaakceptowana usługa na bohatera, na konkretny Artificer, na dzień. Odmowa jest darmowa; następnego dnia ponownie obowiązuje normalna cena. Wymóg co najmniej 100 ruchu jest celowo bardziej rygorystyczny niż w WoG. Nie wdrażano dynamicznych cen ani wspólnego licznika dwóch usług — wymaga to dodatkowego mechanizmu bezpiecznej akceptacji oraz stanu wizyt. Nie zmieniano C++ ani Lua produkcyjnego.

**Testy:** dwa ładowania pełnego portu `vcmiserver --dummy-run` (podstawowy i z aktywnym Mithril oraz Dragon Eye Ring), oba zakończone kodem 0. Natywny harness C++ z niezmodyfikowanymi bibliotekami VCMI, rzeczywistym CRewardableObject, bohaterami i CGameHandler; przechwytywano tylko dialog i stan odpowiedzi, a pakiety zmian były aplikowane do CGameState. Podstawowy profil 8/8; pełny profil powtórzył 8/8 i wykonał 4/4 dodatkowe kontrole (120 receptur, brak Mithril, udana transakcja Mithril, Dragon Eye Ring). W scenariuszu dnia 2 wywołano `newTurn` bezpośrednio. Nie sprawdzono interfejsu klienta, AI, wszystkich 120 indywidualnych transakcji, pełnego plecaka lub złożonych artefaktów, dozwolonych artefaktów na konkretnej mapie ani zapisów ze starszą konfiguracją.


## Aktualizacja — Artificer 1.0.2 (teksty)

Zachowano 47 wpisów ERT (126000–126046) i oryginalny plik. Wszystkie 120 ofert korzysta z dialogów opartych na WoG; odmowy rozróżniają niedobór ruchu, artefaktów, złota i Mithrilu. Podpięto komunikaty zmęczenia i dymki. Angielski i polski tekst w osobnych plikach JSON; nazwy oddawanych artefaktów pozostają angielskie, a nazwa otrzymywanego jest podstawiana przez silnik. Komunikat sukcesu 126046 pozostaje nieaktywny, gdyż natywna ścieżka `onBlockingDialogAnswered` nie pokazuje oddzielnego okna po przyjęciu nagrody. Menu, stronicowanie i druga usługa pozostają poza implementacją. Ceny, 120 receptur i limity bez zmian. Testy natywne 12/12 w obu językach, headless kod 0; bez testu graficznego i wszystkich pojedynczych receptur.


## Aktualizacja — Alms House 1.0.1

**Źródło:** `script018.erm` (OB63/24, FU611, FU610) oraz `script018.ert` (118000–118018), dostarczone WoG 3.59 alpha.

**Zrealizowano:** 100 złota przy zerowym skarbcu; pozostałe zasoby po 1; dokładne progi statystyk i XP <1000 zamiast poziomu bohatera; ruch >0; zerowanie ruchu według oryginalnego licznika; trwała jednorazowa wizyta na bohatera niezależnie od budynku (`visitMode: bonus`, `NONE`, `PERMANENT`). Zachowano także zużycie wizyty bez pomocy lub ruchu. Wszystkie 19 tekstów źródłowych zarchiwizowano, dialogi podłączono z tłumaczeniami EN/PL (nazwę bohatera zastąpiono określeniem This hero). Trzy zakończenia zależą od liczby przyznanych form pomocy.

**Osobliwość oryginału:** próg nagrody XP <1000, ale licznik pomocy wzrasta tylko przy XP <200. Przy samym XP 200–999 bohater otrzymuje nagrodę bez utraty ruchu i słyszy odmowę pomocy. Zachowano świadomie w tej wersji.

**Różnice:** standardowy mechanizm VCMI może modyfikować XP przez Learning itp.; progi statystyk bazują na aktualnych wartościach odczytywanych przez silnik; nie potwierdzono identycznego traktowania artefaktów i efektów tymczasowych w ERM.

**Testy:** pełny port `vcmiserver --dummy-run` kod 0; natywne testy rzeczywistych obiektów 11/11 (dwa budynki, drugi bohater, brak pomocy, brak ruchu, 11 darów, 5 progów XP). Test XP ręcznie wznawia zdarzenie `experienceApplied` po przyznaniu XP bez dialogu awansu. Nie testowano klienta graficznego, zapisu i odczytu, AI, fizycznego wejścia na pole, naturalnego awansu ani polskich dialogów w silniku. Testowa mapa ma ostrzeżenie o brakującej animacji bohatera `ah00_e`, bez wpływu na sprawdzane zdarzenia.


## Aktualizacja — Alms House 1.0.2 (korekty błędów oryginału)

**Decyzja:** naprawiono dwa uzgodnione odstępstwa od WoG 3.59. Nagroda 1000 bazowych XP przy XP <1000 zawsze zwiększa licznik pomocy (26 wystąpień warunku w trzech limiterach pożegnania); jeżeli to jedyny dar, bohater traci resztę ruchu i otrzymuje właściwe pożegnanie 118017. Nagroda XP wlicza się również do progu czterech darów (118018). Wizyta z zerowym ruchem wyświetla oryginalny komunikat 118001, ale nie przyznaje trwałego znacznika NONE; po odzyskaniu ruchu można wrócić do dowolnego Alms House. Wizyta z ruchem, bez kwalifikujących się darów, nadal zużywa jednorazową wizytę. Reszta mechaniki, tłumaczenia EN/PL i wszystkie 19 źródłowych wpisów ERT pozostają bez zmian. Nie zmieniono C++ ani Lua.

**Weryfikacja:** pełny port VCMI 1.8 `vcmiserver --dummy-run`, kod 0; test natywny 15/15 (wcześniejsze 11 kontroli z aktualizacją oczekiwań dla dwóch poprawek, dodatkowo powrót do tego samego i innego obiektu oraz progi 3/4 darów z XP). W testach ręcznie ustawiano stan bohatera i wznawiano procedurę nagród XP bez dialogu awansu. Nie testowano naturalnego przemieszczania, klienta graficznego, AI, zapisu/odczytu ani polskich tekstów w silniku. Pozostaje ostrzeżenie o animacji ah00_e na mapie testowej. Zalecany nowy zapis gry; poprzednio przyznane trwałe znaczniki nie są automatycznie usuwane.


## Aktualizacja — New Chest II v0.1.1

Źródło: `wog-master/Mods/WoG/ERM/script031.erm` (FU5200–5208) oraz aktywne rekordy `script031.ert` 131000–131034. Zachowano 35 aktywnych i 29 historycznych rekordów oznaczonych #. Poprzednie twierdzenie o natychmiastowym +1 w oryginalnym skrypcie jest błędne: w52=S7, timer zmniejsza w52, przy w52=1 HE:Sw53/3 ustawia Expert.

- Wstępne szanse 40/40/20% pozostają bez zmian. Wariant zwoju: 300–900 złota w obu opcjach, 30 many na poziom zwoju z przekroczeniem limitu. Poprawiono poziom zwoju z przedziałów co 10 poziomów na dokładny algorytm FU5200 (co 5 poziomów oraz losowanie +1/+2). Od 20 poziomu zawsze L5. Losowanie kategorii i dodatkowej premii skorelowano w jednym równomiernym dice 0–99; wyniki kategorii i bonusowego rzutu mają właściwe rozkłady.
- Księgi: co najmniej dwie standardowe znane umiejętności Basic/Advanced; przy 0 lub 1 prawidłowa alternatywa scroll+gold zamiast 500 złota lub awansu jedynej umiejętności. Wybrana umiejętność osiąga Expert (przyrost +2 ograniczony przez silnik do Expert). Nie powstaje nowa umiejętność.
- Kompromis: natychmiastowy Expert zamiast 7 dni, wszystkie kwalifikujące się standardowe umiejętności zamiast dwóch losowych, bez przypomnień i blokady nauki. LuaModule::createMapScriptDispatcher wymaga scriptSource w konkretnej mapie; nie stwierdzono ogólnomodowego haka do rozpoczęcia/ukończenia nauki. Nie dodano zmian C++ ani Lua.
- Akt własności: zachowano rekompensatę 2000 złota; nie ma przejęcia neutralnej kopalni, odsłonięcia mapy ani fallbacku w przypadku braku kopalni. WoG ma dodatkowe wyjątki Mithril, Living Scrolls, Adventure Cave (podwójne złoto) oraz AI (1500 XP zamiast many), a także próby unikania posiadanych już zwojów. Nieodtworzone. Losowanie w VCMI przy inicjalizacji obiektu, nie w momencie wizyty.
- Dialogi: zachowano pełne źródła i teksty, aktywne adaptacje EN/PL. `selectPlayer` używa jednego onSelectMessage dla wszystkich wariantów; po wyborze nie wyświetla odrębnego komunikatu nagrody. Zachowano oryginały nieaktywnych tekstów.
- Testy: statycznie 12 000 kombinacji i natywnie 300 kontroli limiterów + 5 scenariuszy przyznania nagród. --dummy-run kod 0, All game content loaded. Początkowa próba natywna z wielokrotnym losowaniem 25 przedziałów przekroczyła 45 s; próbka trzech kategorii zakończyła się sukcesem. Żądanie odroczonego usunięcia sprawdzono, lecz faktyczne usunięcie, pełna wizyta, AI, RMG, klient, polska lokalizacja i save/load nie były testowane. Konfiguracja 141 wpisów i zagnieżdżone limitery (738 kB); wydajność dużych map wymaga weryfikacji.


## Aktualizacja — Palace of Dreams v1.0.1

Źródła: `wog-master/Mods/WoG/ERM/script011.erm` (OB63/33, FU777, FU778, FU779), `script011.ert` (111000–111022), VCMI `lib/rewardable/Interface.cpp`, `Info.cpp`, `Reward.cpp`, `lib/mapObjects/CRewardableObject.cpp` i `lib/json/JsonRandom.cpp`.

- WoG: 100 złota za spin, koszt wejścia 400 ruchu przy dodatnim ruchu (także przy odmowie lub braku złota), dwa automaty do wyboru, do 100 gier na sesję, trzy bębny. Dla maszyny surowcowej enumeracja wszystkich 392 trójek i 8 masek kopiowania (ważonych 30/31 i 1/31) daje 3,3635004% wygranych, w tym 0,772696% złota. Maszyna artefaktowa zależy od puli dopuszczonych artefaktów, ma losowanie R/T i reroll reliktów.
- VCMI: 100 złota i do 400 ruchu na kwalifikującą się wizytę, minimum 1 ruchu; bez opłaty przy niespełnieniu warunków. Jedna automatyczna gra dziennie na pałac, wspólna dla wszystkich bohaterów i graczy. Nie ma oddzielnego potwierdzenia: `canRefuse` pokazałoby składniki wylosowanej nagrody, umożliwiając odmowę przegranej. `showScoutedPreview` wyłączone.
- Przyjęta adaptacja dwóch automatów: jeden ukryty dice 0–99; 0–96 strata, 97 surowiec, 98 równomierne losowanie straty/surowca/złota, 99 równomierny wybór jednego z 10 wpisów artefaktów (4 Treasure, 3 Minor, 2 Major, 1 Relic). Łączna szansa 2⅔%, w tym 1⅓% surowce, ⅓% złoto i 1% artefakt. Klasy i łączna szansa są przybliżeniem, nie dokładnym algorytmem oryginału. Losowanie częściowo przy inicjalizacji i resecie; reszta przy wizycie.
- Nagrody według `FU777`: floor(dzień/7)+4+R(0,4) jednostek jednego z sześciu surowców; złoto dzień×100+4000+R(0,100), netto po odjęciu 100. Dokładny dzień do 112, następnie przedziały co 7 dni od 113, limit od dnia 365. Brak osobnej animacji bębnów i ponownego zakładu. Wszystkie nagrody artefaktowe pobierają 100 złota; nie ma dodatkowych bonusów 2000/5000 ze starego portu. VCMI może stosować fallback klasy w razie pustej puli.
- Zachowano 23 oryginalne wpisy ERT (w tym dwa puste), ERM i ERT bez zmian, aktywne adaptacje EN/PL; teksty ponownej gry i menu zachowano nieaktywne. RMG/aiValue bez zmian, ale niższe szanse wygranej wymagają praktycznego sprawdzenia atrakcyjności obiektu.
- Testy: 40 000 kombinacji statycznych, headless kod 0, osiem grup kontroli natywnych (w tym siedem dat oraz trzy kandydatury gałęzi mieszanej); wypłata złota przez wizytę z pozostałymi kandydatami wyłączonymi tylko w testowym obiekcie. Natywny przebieg końcowy kod 0. Początkowy błąd linkowania dotyczył niewyeksportowanych funkcji; pierwszy przebieg miał błąd przy niszczeniu fixture po usunięciu biblioteki; skorygowano program testowy. Nie testowano chodzenia, GUI, polskich komunikatów w silniku, AI, RMG, zapisów, pełnego plecaka ani skrajnych ograniczeń artefaktów. Bez Lua i zmian C++.


## Aktualizacja — Death Chamber v1.0.0

Źródło: `wog-master/Mods/WoG/ERM/script070.erm` (FU14306, FU14310, BF, BR, BA1; przemiana linie 469–516), `script070.ert` (170000–170058). VCMI: `CRewardableObject::newTurn`, `initializeGuards`, `GameStatePackVisitor::visitSetRewardableConfiguration`, Lua `GAME:getCalendar`, `BattleServer`.

- Usunięto obowiązkową zależność od WoG Creatures. Wersja podstawowa: Lich King, Power Lichy, Zjawy w późnej fali; wyłącznie złoto. Opcjonalne `creaturesCompatibility` zależy od `wake-of-gods.creatures`: Ghosts w walce i nagrodzie, przemiana od dnia 22 w osobnego Dracolich Kinga. Nie nadpisuje zwykłego Dracolicha. Mithril zależy od `wake-of-gods.mithril`, a nie od Creatures. Przy obu opcjach należy włączyć także zagnieżdżone `mithrilCompatibility`, które scala nagrody. Jawne zależności wszystkich patchy rozwiązują problem identyfikatorów przy instancjonowaniu obiektu.
- Pięć poziomów trudności (j=0–4); Lich King A/D=100, speed=40, HP=160+20*(tier-1)+2*growth, damage=14+2*tier+growth. Dracolich King HP=770+15*tier+5*growth, damage=59+2*tier+growth, 1000 strzałów, podwójny atak, nielimitowane kontrataki. `growth=max(0,week-2)`, zawsze włączony. Przemiana na początku bitwy zamiast w pierwszej turze króla; jeśli nie ma odpowiedniego heksu, pozostaje Lich King. Wariant bazowy zachowuje Lich Kinga również w późnej grze.
- Pierwsza fala: 11 (Dracolich: 10) oddziałów Power Lichów po 2*tier+growth. W źródle BR zmienna m zerowana, potem m += v1176, m *= 2, stąd późna fala Ghosts po 2*(2*tier+growth), nie zależna od poziomu bohatera. Zachowano dotychczasową adaptację rundy 2 i 3 i geometrię 30 przeszkód, a nie oryginalne warunkowe przywołanie po śmierci króla, losowe dodatkowe rodziny przeciwników i specjalne rozmieszczenie oddziałów. Piąta trudność korzysta z czwartej klątwy. Armageddon od rundy 2: 80 bazowych obrażeń na oddział atakujący, przez applySpellEffects, nie pełny globalny czar z animacją; świadoma adaptacja ze względu na ochronę własnych wojsk i brak wiernego cyklu Anti-Magic. Nie przywrócono 50% Inferno, Expert Anti-Magic, wyłączenia Tactics ani animacji przemiany. Starsze czary i fazy zachowane.
- Złoto 12000/14000/16000/18000/20000 + 100*growth +4000 od tygodnia 4; Ghosts 10/12/14/16/18 +2 od tygodnia 4; Mithril 8/10/12/14/16 +growth +4 od tygodnia 4. Premia późna również w wersji podstawowej bez przemiany (decyzja adaptacyjna). Nagrody ograniczone od dnia 365; siła bojowa rośnie dalej. Zastosowano przedziały tygodniowe i wspólną kość trudności. Tylko pierwszy wpis każdego przedziału trudności zawiera strażnika, gdyż silnik nie sprawdza limiterów przy tworzeniu gwardii.
- Reset globalny dni 29, 57, 85 itd. zamiast 28 dni od zwycięstwa, dotyczy też niezdobytych komnat i ponownie losuje trudność. RMG bez zmian. Wszystkie 59 wpisów ERT zachowane (również ścieżki grafik), aktywna wersja ostrzeżenia składa się z jednego zestawu oryginalnych fraz, nagrody i odwiedzone z oryginału lub adaptacji; oryginalne ERM/ERT archiwizowane, aktywne EN/PL osobno.
- Testy: 4800 statycznych kombinacji dat/kości/dodatków; 4 profile zależności po 5 dat (1,21,22,29,57) = 20/20 natywnych scenariuszy. Sprawdzono rzeczywistą instancję obiektu, nagrodę kwalifikującą się do wypłaty, odmowę, stan strażników, 30 przeszkód, HP i tożsamość króla, liczbę i liczebność początkowych Power Lichów, obie fazy rund i liczebność Ghosts/Zjaw, reset syntetycznie oczyszczonego obiektu w dniu 29. Cztery izolowane i jeden pełny headless: kod 0. Wczesne błędy jawnych zależności, testowego wyszukiwania pola bitwy i globalnego Armageddonu naprawione. Testy wywołują zdarzenia bezpośrednio; nie rozegrano pełnej bitwy ani wypłaty po naturalnym zwycięstwie, nie testowano ucieczki/porażki i zachowania zastąpionego króla w armii obiektu, GUI/grafik, AI, RMG, zapisu/odczytu, polskich dialogów, wszystkich pięciu stopni natywnie ani wydajności na dużych mapach. Bez zmian C++ silnika.


## Aktualizacja — Potion Fountains v1.0.1

Źródło: WoG 3.59 alpha `script017.erm`, OB63/2, OB30/0, OB63/48, FU800–816, BA0/BA1; `script017.ert` 117000–117019. VCMI: `Rewardable::Interface::grantRewardAfterLevelup`, `doHeroVisit`, `UnitOnHexLimiter`, `BonusList::stackBonuses`, `CBattleInfoCallback::battleCanCastSpell`, `BattleResultProcessor.cpp` i `GameStatePackVisitor::visitDischargeArtifact`.

- WoG zapisuje dawki w zmiennych w10 (Hydromel), w11 (Berserker), w12 (Venus), każda wizyta ustawia 3. VCMI zachowuje artefakty z trzema ładunkami BATTLE. `takenArtifacts` usuwa jeden posiadany flakon danego typu przed przyznaniem nowego; brak tygodniowego limitu dla Venus/Valhalla. Hydromel przy ponownej wizycie odnawia flakon przez `onVisited`, bez kolejnego bonusu Luck; zachowano oryginalny natywny efekt Fountain of Fortune (−1/+1/+2/+3, 25% każdy). Normalne wizyty nie mnożą kopii; starsze duplikaty, wymiana i łup nadal możliwe.
- PRIMARY_SKILL, LUCK i MORALE mikstur ograniczono do stosów na polu bitwy przez `UNIT_ON_HEXES` (0–186). Nie zwiększają statystyk bohatera na mapie. Wartości: Hydromel +2/+2, Berserker +10 Attack i co najmniej +3 Luck, Venus co najmniej +3 Luck/Morale; zwykłe ograniczenia morale i szczęścia pozostają. `stacking` wspólne dla kopii danego typu. Berserker: `HERO_SPELL_CASTS_PER_COMBAT_TURN`, val=0, INDEPENDENT_MIN; zamiast `BLOCK_MAGIC_BELOW`, które obejmowało także czary stworzeń. Nie zeruje many, a blokuje limit rzucania czarów bohatera w bitwie.
- Świadoma adaptacja: wybór przez założenie/zdjęcie flakonu przed walką zamiast dialogu BA0, zużycie po walce według natywnego mechanizmu artefaktów, slot MISC. W WoG AI pije Hydromel po obu stronach, nie pije Berserkera, Venus pije jako atakujący (FU814), ale nie jako obrońca (FU815); komentarz nagłówka jest niespójny z kodem. Zasady AI/MP nie są odtworzone. Oryginalne mieszanie Hydromel+Berserker może trwale obniżyć Spell Power o 1 (FU812, losowanie 0–100 >50, podstawowa wartość >1). Efekt niezaimplementowany, nie ma fałszywego ostrzeżenia w aktywnym opisie. Możliwość przenoszenia/zdobywania flakonów i miejsca w ekwipunku pozostaje różnicą. RMG bez zmian. Bez Lua i zmian C++.
- Zachowano 20/20 wpisów ERT oraz oryginalne ERM/ERT. Trzy aktywne dialogi napełniania adaptują imię/zaimki do drugiej osoby; niewykorzystane pytania przed bitwą i reakcja niepożądana zachowane archiwalnie. Teksty EN/PL w osobnych plikach, domyślne identyfikatory tekstów artefaktów z nadpisaniami tłumaczeń.
- Testy natywne: 4/4 grupy. Rzeczywiste instancje trzech fontann i dwóch bohaterów, początkowe 3 dawki, zmniejszenie ładunków przez natywny pakiet, ponowne napełnienie bez duplikatu, zachowanie Luck, zniknięcie po wyczerpaniu, niezależna wizyta, statystyki bohatera na mapie, bonusy stosu w bitwie +12 A/+2 D, Luck/Morale=3, limit czarów bohatera=0 i zachowany limit wroga, brak ograniczenia poziomu zaklęcia. Pierwsza próba porównania sum stosu mapy i bitwy nie przeszła (różnica jednego punktu); końcowa kontrola sprawdza konkretne bonusy z mikstur. Pełny port --dummy-run kod 0. Nie rozegrano całej bitwy ani nie przetestowano automatycznego zużycia po jej zakończeniu, zdejmowania artefaktu, transferów, pełnego plecaka, AI, MP, GUI, polskich napisów w kliencie, zapisów, RMG, specjalnych jednostek ani faktycznej próby rzucenia zaklęcia. Testy z pakietami nie są testem pełnego cyklu bitwy.


## Aktualizacja — Potion Fountains v1.0.2

Na życzenie użytkownika usunięto sześć limiterów UNIT_ON_HEXES z bonusów trzech mikstur. Attack, Defence, Luck i Morale działają również na mapie przygód podczas noszenia artefaktu; jest to świadome odstępstwo od WoG, mogące wpływać na wymagania obiektów mapy. Zachowano trzy ładunki BATTLE, removeOnDepletion, stacking, blokadę czarów bohatera w bitwie, konfigurację fontann oraz oryginalne ERM/ERT. Dostosowano aktywne opisy EN/PL. Natywna regresja 4/4 grup (kod 0): +12 Attack/+2 Defence bohatera na mapie, dokładne wkłady bonusów w bitwie, Luck/Morale=3 w bitwie, limit zaklęć i uzupełnianie/zużycie pakietowe. Nie testowano nowego wydania w GUI, pełnego końca bitwy ani zachowania w plecaku. Bez zmian Lua/C++.


## Aktualizacja — Battle Academy v1.0.1

Źródła: `wog-master/Mods/WoG/ERM/script016.erm` (w38, FU3611–3619, TM30; wersja skryptu 1.41), `script016.ert` (116000–116039); VCMI `lib/rewardable/Limiter.cpp`, `Interface.cpp`, `Info.cpp`, `lib/mapObjects/CRewardableObject.cpp`, `lib/mapObjectConstructors/CRewardableConstructor.cpp`, `lib/gameState/GameStatePackVisitor.cpp`.

- Akademia szkoli bohaterów, nie oddziały; w WoG nie przyznaje Stack Experience. Zachowano 198 wariantów +1 Attack/Defence, trzy warianty szkolenia umiejętności i 16 zwykłych artefaktów (217 ofert); dodatek Commanders dokłada pięć ofert (222). Koszt 500 × bieżąca statystyka, 0→1 za darmo; przy statystyce 99 brak oferty. Osiem umiejętności, 3000 złota za poziom. Sprawdzono wszystkie 16 cen artefaktów względem trzykrotności kosztu z artraits.txt; dowódcze 15000. RMG bez zmian.
- `visitMode: bonus` i `NONE` o trwałości `ONE_DAY` we wszystkich 222 gałęziach. Jedna zaakceptowana usługa dziennie na bohatera we wszystkich akademiach, odmowa lub brak oferty nie zużywają limitu. Reset puli nagród codziennie, bez osobnego resetu listy gości. Obiekt nie ma nowej zależności od Stack Experience ani Commanders. Opcjonalny podmod wymaga Commanders.
- Zachowano 40/40 wpisów ERT oraz oba oryginalne pliki bez zmian; aktywne dialogi ofert adaptują oryginalne frazy (116024–116027, 116029–116032, 116018–116020, 116035), blokada dzienna 116001. Nazwy artefaktów/umiejętności są podstawiane przez silnik. Menu, dodatkowy slot, komunikaty po zakupie i odmowie zachowane archiwalnie; 227 kluczy aktywnych EN/PL (nie wszystkie są używane w trybie selectRandom).
- Pozostałe różnice: WoG używa bazowej statystyki (GetBasicPrim), VCMI limiter `primary` używa `getPrimSkillLevel`, a więc także artefaktów i mikstur. Nie stwierdzono odpowiednika w JSON. Pozostawiono obecny limit 0–98, losową ofertę z dokładną ceną i możliwością ponawiania po odmowie; tryb selectPlayer pokazuje tylko jeden komponent nagrody na opcję i nie pokazuje odrębnych cen. WoG ma menu, wspólną dzienną pulę umiejętności i artefaktu (TM30), dodatkową opłatę za naukę przy pełnych slotach (FU3611) oraz wyjątki AI; VCMI ma pulę per budynek i dodatkową pulę dowódczą, wymaga wolnego slotu do nauki i nie odwzorowuje AI. Bez zmian C++ i Lua.
- Testy: 10/10 kontroli natywnych z dodatkiem, 9/9 bez Commanders, dwa przebiegi headless z kodem 0. Kontrole obejmują brak złota, odmowę, płatny Attack, globalną blokadę, niezależny drugi bohater i darmową Defence, wygaśnięcie ONE_DAY przez natywny pakiet NewTurn, Basic→Advanced, Advanced→Expert, zakup zwykłego artefaktu oraz Hardened Shield za 15000. Pierwszy test przerwano przez błędne czyszczenie stanu dialogu w fixture; naprawiono program testowy, nie produkcyjny JSON. Nie testowano wszystkich artefaktów i umiejętności indywidualnie, nauki Basic z pustego slotu, pełnych slotów, cen przy miksturze w natywnej wizycie, GUI, AI, polskich dialogów w silniku, save/load ani RMG.


## Aktualizacja — Arcane Tower v1.0.1

Źródła: `wog-master/Mods/WoG/ERM/script004.erm` (v1.7, OB63/9, FU620–624, GetBasicPrim), `script004.ert` 104000–104015. VCMI: `lib/rewardable/Limiter.cpp` (heroAllowed), `Interface.cpp` (grantRewardBeforeLevelup, loadComponents), `lib/mapObjects/CGHeroInstance.cpp` (setPrimarySkill, getBasePrimarySkillValue), `lib/bonuses/BonusCache.cpp` oraz `config/gameConfig.json`.

- WoG pozwala człowiekowi wybrać zysk i koszt, powtarzać tę samą wymianę do 30 razy w pętli FU624. Nie pobiera punktów ruchu. GetBasicPrim sprawdza wartość bazową; minimum po wymianie: Attack/Defence 0, Spell Power/Knowledge 1. W VCMI zachowano celową adaptację z istniejącej konfiguracji: 300 ruchu za transakcję, jeden losowy kwalifikujący się wariant, bezpłatna odmowa, 12 kierunków, nieograniczone wizyty. Nie dodano nauki czarów ani punktów statystyk za złoto (nie występują w Script 04).
- Dodano `noneOf` z progiem 99 dla zwiększanej cechy (standardowy limit widocznej statystyki VCMI), aby nie oferować wymiany na cechę już na maksimum. Jest to sprawdzenie efektywnej wartości, nie bazowej. Nie zmieniono RMG, grafiki ani kosztu ruchu.
- Zachowano wszystkie 16/16 wpisów ERT, oryginalne ERM/ERT i archiwum strings.json. 15 kluczy aktywnych w każdym z plików EN/PL. Teksty 104001, 104002, 104007–104010 i 104011 wykorzystano w adaptacji ofert/odmowy braku możliwości; oryginalne zagnieżdżone wybory i tekst po zaakceptowaniu pozostają archiwalne. `selectPlayer` pokazuje tylko jeden komponent nagrody na opcję, więc zachowano jednoznaczny dialog jednej wymiany.
- **Nierozwiązane ograniczenie:** `primary` sprawdza `getPrimSkillLevel` (wlicza artefakty i mikstury), zaś `changePrimSkill` zmienia HERO_BASE_SKILL. Test rzeczywistego Hydromelu: Attack bazowy 0, efektywny 2, wymiana na Spell Power powoduje surową wartość bazową Attack -1 i Spell Power 2. Widoczna statystyka jest ograniczona do minimum, co może prowadzić do nadużyć. Nie znaleziono bazowego limitera w schemacie JSON. Ostrzeżenie w aktywnym dialogu i opisie zaleca zdjęcie wyposażenia oraz niewymienianie punktów z bonusów. Nie jest to techniczna blokada. Nie zmieniono mikstur, silnika ani Lua. Wersja do świadomych testów, nie pełna zgodność z WoG.
- Testy: 17 pozytywnych kontroli/grup natywnych (12 kierunków, odmowa i dostępność, próg ruchu, minima, limit 99, ponowne wizyty w obu wieżach), dodatkowy scenariusz odtwarzający nierozwiązany błąd Hydromelu. Pierwsza próba linkowania programu testowego nie powiodła się z powodu niewyeksportowanej metody getAvailableRewards; użyto natywnego Limiter::heroAllowed na rzeczywistej konfiguracji. Końcowy test kod 0. Pełny port --dummy-run kod 0. Nie sprawdzono GUI, AI, MP, RMG, save/load, polskiego klienta ani wszystkich kombinacji tymczasowych bonusów.
