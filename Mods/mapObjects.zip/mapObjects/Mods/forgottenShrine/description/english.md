# Forgotten Shrine

*Long abandoned by its keepers, this weathered shrine still shelters an ancient spirit. Those who seek its blessing must offer their strength for the day, but the spirit may come to their aid when battle begins.*

## How it works

Visiting the **Forgotten Shrine** allows a hero to pray for **one randomly chosen blessing**. The chosen spell is prepared for the hero's **next battle** and is cast automatically at the beginning of that battle, at **Expert mastery**. Its configured duration is **50 combat rounds**, provided that the spell's effects can apply.

The shrine offers **20 possible spells**. Each blessing is chosen randomly; the hero cannot select the spell.

| Visiting rule | Effect |
| --- | --- |
| Minimum movement | The hero must have **at least 201 movement points** remaining. |
| Prayer cost | **All remaining movement points** are consumed. |
| Choice | The hero may **decline** the prayer without taking the blessing. |
| Reward | One random Expert-level spell prepared for the **next battle**. |
| Duration | **50 rounds** of that battle, subject to normal spell behavior. |
| Repeat visits | A hero cannot obtain another shrine blessing **while one remains active**. Once that bonus has expired, the shrine can be used again. |

## Possible blessings

**Protection and survival:** Shield, Air Shield, Fire Shield, Protection from Air, Protection from Fire, Protection from Water, Protection from Earth, Anti-Magic, Stone Skin, and Magic Mirror.

**Attack and battlefield advantage:** Bless, Bloodlust, Precision, Prayer, Mirth, Fortune, Haste, Slayer, Frenzy, and Counterstrike.

The spell is cast for the army at battle start; **a particular creature's immunity or the spell's targeting rules may prevent it from benefiting**. In particular, do not assume that every special spell affects every troop in exactly the same way.

## Advice for adventurers

The shrine is most valuable just before a difficult encounter: its blessing is saved for the next battle, but the prayer leaves the hero unable to move farther that day. If you have 200 movement points or fewer, you will need to return when you have more strength. You do not need to know the chosen spell or have it in your spellbook to receive the shrine's battle-start effect.

A blessing is **not a permanent spell learned by the hero**. Nor does the shrine award gold, resources, artifacts, or experience.

---

*This description reflects the Forgotten Shrine VCMI submod's current configuration. The mod has passed a headless loading check, and an in-game player report indicates that it appears to work. The exact behavior of special spells, immunities, and battlefield restrictions has not been independently verified for every combination.*
