# War Machines on Map — Player Guide

Some treasures have uses far beyond their sale value. **War Machines on Map** makes war machines and the Grail available as adventure-map artifacts, offering unusual finds as you explore.

## What Can You Find?

- **Ballista** — a war machine that can support your army with ranged attacks.
- **First Aid Tent** — a support war machine used to heal creatures during battle.
- **Ammo Cart** — supplies ammunition for ranged troops.
- **Catapult** — a siege machine used in town assaults.
- **Grail** — a special artifact associated with building a Grail structure in a town.

The actual placement of items depends on the random-map generator and other installed mods. Having the objects enabled does not guarantee that each will appear on every map.

## What About the Spell Book?

In **version 1.0.1**, this mod **no longer adds the ordinary Spell Book** to the pool of adventure-map artifacts. The earlier version allowed a hero to find a normal spellbook, but it did not teach any spells by itself.

For a book that grants spells on discovery, enable the separate **WoG Scripts: Spell Book** submod. Its magical book is an adventure-map *object*, not the normal spellbook artifact. It awards a selection of spells whose quality depends on the hero's Luck and Wisdom; a hero who needs a normal spellbook can also receive one.

## Compatibility

- This mod keeps the same internal identifier and the same five remaining artifact definitions.
- It does not replace or alter normal spellbook behavior in towns, starting hero equipment, scripted rewards, or other mods.
- Another mod may independently make the normal spellbook obtainable on the map.

*VCMI adaptation: version 1.0.1. Tested for mod-data loading in VCMI 1.8.0 headless; map generation, pickups and visuals are not covered by that smoke test.*
